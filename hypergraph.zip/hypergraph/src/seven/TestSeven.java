package seven;
/**
 * tester class for manually tested H(n)
 * 
 * @author lauren ostrea
 * @version 3 March 2021
 */

import java.util.*;
public class TestSeven{
	private final int n = 7; //refers to H(n)
	private int[][] testTable;
	private int[][][] testArray;
	
	/**
	 * constructor method
	 */
	public TestSeven() {
		this.testTable=testTable;
	}
	
	/**
	 * finds the lower bound Tn where k1 = 1 
	 * and kn = (n/2)+k(n/2)+k(n+1/2)
	 * @return Tn (lower)
	 */
	public int findLowerTn(int n) {
		int Tn;
		int tLeft, tRight;
		int N = 2;
		int Kn[] = new int[n];
		Kn[0]=1; //permanently sets H(1) = 1
		
		for(int i = 1; i<Kn.length; i++) { //loop to find Tn
			tLeft = N/2; //root of T(n/2)
			tRight = (N+1)/2; //root of T(n+1/2)
			Tn = N/2 + Kn[tLeft - 1] +Kn[tRight - 1];
			Kn[i] = Tn;
			N++;
		}
			Tn = Kn[n-1]; //finds last value in array
			return Tn; 				
	}
	/**
	 * finds the upper bound Tn where k1 = 1 
	 * and kn = (n/2)+k(n/2)+k(n+1/2)
	 * @return Tn (upper)
	 */
	public int findUpperTn(int n) {
		int lowTn = findLowerTn(n);
		int upTn = lowTn + 1;
		return upTn;
	}
	/**
	 * initializes table of 0 according to n-input.
	 * then fills in values for lower bound Tn. 
	 * the size of table is rows = Tn and col = n
	 */
	public int[][] createLower(int n, int set) {
		int Tn = findLowerTn(n);
		int basement = Tn - 2;
		testTable = new int [Tn][n];
		
		for(int i = 0; i < testTable.length; i++){
			for(int j = 0; j < testTable[i].length; j++){
				if(i<=n) { //fills top half of table with matrix I[n][n]
					if(i==j) testTable[i][i] =1;
					else testTable[i][j]=0;
				}
				if(i > n-1 && i<=12) {  //fills rows 8-13 with test values
					testTable[i]=getSet(i);
				}
				if(i>=13 && i<basement) {
					testTable[i]=getToTest(set);
				}
				if(i>=basement) { //fills bottom (basement) of table
					testTable[i][j]=1; //bottom two rows filled with 1
				}
			}
		} return testTable;
	}
	/**
	 * initializes table of 0 according to n-input.
	 * then fills in values for upper bound Tn+1. 
	 * the size of table is rows = Tn+1 and col = n
	 */
	public int[][] createUpper(int n, int Tn, int set) {
		int basement = Tn - 2;
		testTable = new int [Tn][n];
		for(int i = 0; i < testTable.length; i++){
			for(int j = 0; j < testTable[i].length; j++){
				if(i<=n) { //fills top half of table with matrix I[n]
					if(i==j) testTable[i][i] =1;
					else testTable[i][j]=0;
				}
				if(i>n-1 && i<=13) { //fills rows 8-13
					testTable[i]=getSet(i);
				}
				if(i>=14 && i<basement) { //fills rows to test
						testTable[i]=getToTest(set);
				}
				if(i>=basement) { //fills bottom (basement) of table
					testTable[i][j]=1; //bottom two rows filled with 1
				}
			}
		} return testTable;
	}
	/**
	 * fills the middle of test table
	 * @return 1D array 
	 */
	public int[] getSet(int i){
		int[][] set = {{1,1,0,0,0,0,0},{0,0,1,1,0,0,0},{0,0,0,0,1,1,0},
				{0,0,0,0,1,1,1},{1,1,1,1,0,0,0},{1,1,1,1,0,0,0},{1,1,1,1,1,1,0}};
		int[] toSet = set[i-7];
		return toSet;
	}
	//1,0,0,1,0,1,1
	/**
	 * gets the total sum of all columns in the test table
	 * where no blobs (columns) have been deleted yet
	 * @return 2D array 
	 */
	public int[] getSumArray(int n, int[][] arr) {
		int total;
		int[] sum = new int[arr.length];
		for(int i = 0; i < arr.length; i++) {
			total = 0;
			for(int j = 0; j<arr[i].length;j++) {
				total+= arr[i][j];
			}
			sum[i]=total;
		}
		return sum;
	}
	/**
	 * checks that a column in the test table is <= 7
	 * @return true if check <=7, false if check > 7
	 */
	public boolean checkSum(int[] sum) {
		int n=7;
		int ones=0;
		boolean check = true;
		
		for(int s = 0; s<sum.length; s++) {
			if(sum[s] == 1) ones += sum[s];
		}
		
		if(ones <= n) check = true;
		else check = false;
		
		return check;
	}
	
	public void printTotal(int[] sum) {
		int ones=0;
		for(int s = 0; s<sum.length; s++) {
			if(sum[s] == 1) ones+=sum[s];
		}
		System.out.println(ones);
	}
	
	public void printSum(int[] sum, int[][] arr) {
		boolean check = checkSum(sum);
		System.out.println("\nAdding columns together...");
		System.out.println("\nA    B    C    D    E    F    G");
		System.out.println("-------------------------------");
			
		for(int i = 0; i < arr.length; i++) {
			for(int j = 0; j < arr[i].length; j++) {
				System.out.print(arr[i][j] + "    ");
			}
			System.out.println();
		}
		String total = Arrays.toString(sum);
		System.out.print(total + " --> " + check + " ");
		printTotal(sum);
		System.out.println("");
	}

	
	
	
	public int[][] removeBlobs(int n, int[][] test, int b){
		int[] blobs;
		int[][] newTest;
		int row = test.length;
		int col = test[0].length; 
		int colRemove, num, temp;
		
		//for loop, get a blob combo to remove using getBlob method
			num = getBlobCombo(b).length; //finds # of blobs to delete
			blobs = getBlobCombo(b); //finds actual array of blobs to delete
			newTest = new int[row][n]; //stores new test matrix
			
			//for loop, get individual blobs in a combo
			switch(num) {
				case 1:
					for(int i = 0; i < row; i++) { 
						for(int j = 0; j < col; j++) {
							if(j == blobs[0]) {
								newTest[i][blobs[0]]=0;
							}
							else newTest[i][j] = test[i][j];
						}
					} break;
				case 2:
					for(int i = 0; i < row; i++) { 
						for(int j = 0; j < col; j++) {
							if(j == blobs[0] || j == blobs[1]) {
								newTest[i][blobs[0]]=0;
								newTest[i][blobs[1]]=0;
							}
							else newTest[i][j] = test[i][j];
						}
					}break;
				case 3:
					for(int i = 0; i < row; i++) { 
						for(int j = 0; j < col; j++) {
							if(j==blobs[0] || j==blobs[1] || j==blobs[2]) {
								newTest[i][blobs[0]]=0;
								newTest[i][blobs[1]]=0;
								newTest[i][blobs[2]]=0;
							}
							else newTest[i][j] = test[i][j];
						}
					}break;
				case 4:
					for(int i = 0; i < row; i++) { 
						for(int j = 0; j < col; j++) {
							if(j==blobs[0] || j==blobs[1] || j==blobs[2] || j==blobs[3]) {
								newTest[i][blobs[0]]=0;
								newTest[i][blobs[1]]=0;
								newTest[i][blobs[2]]=0;
								newTest[i][blobs[3]]=0;
							}
							else newTest[i][j] = test[i][j];
						}
					}break;
				case 5: 
					for(int i = 0; i < row; i++) { 
						for(int j = 0; j < col; j++) {
							if(j==blobs[0] || j==blobs[1] || j==blobs[2] 
								|| j==blobs[3] || j==blobs[4]) {
								newTest[i][blobs[0]]=0;
								newTest[i][blobs[1]]=0;
								newTest[i][blobs[2]]=0;
								newTest[i][blobs[3]]=0;
								newTest[i][blobs[4]]=0;
							}
							else newTest[i][j] = test[i][j];
						}
					}break;
				case 6:
					for(int i = 0; i < row; i++) { 
						for(int j = 0; j < col; j++) {
							if(j==blobs[0] || j==blobs[1] || j==blobs[2] 
								|| j==blobs[3] || j==blobs[4] || j==blobs[5]) {
								newTest[i][blobs[0]]=0;
								newTest[i][blobs[1]]=0;
								newTest[i][blobs[2]]=0;
								newTest[i][blobs[3]]=0;
								newTest[i][blobs[4]]=0;
							}
							else newTest[i][j] = test[i][j];
						}
					} break;
			} 
			return newTest;
	}
	
	public void createTest(int n) {
		int Tn = findLowerTn(n);
		int k=63;
		int[] sumArray;
		int[] bye = new int[126];
		int[][] low = createLower(n,k);
		int[][] up = createUpper(n,Tn,k);
		
		boolean checkFirst;
		boolean test = true;
		
		System.out.println("H(7): testing tables...");
			sumArray = getSumArray(n,low); //gets sum of 1's with no blobs removed
			checkFirst = checkSum(sumArray); //checks if sum <= 7
			
			if(checkFirst == true) { //if sum <= 7, run blob test
				printSum(sumArray, low);
				for(int i = 0; i<bye.length; i++) { //starts blob test
					int[][] noBlob = removeBlobs(n,low,i);
					sumArray = getSumArray(n,noBlob);
					test = checkSum(sumArray);
					printSum(sumArray, noBlob);
				
					if(test == false) {
						isWrong(low);
						k+=1;
						break;
					}
					if(i==bye.length-1) { //if done with blob test, end loop
						isRight(low, Tn);
						break; 					
					}
				
				}
			}
			else if(checkFirst == false){ //if sum > 7, end test
				isWrong(low);
			}
	}
	
	/**
	 * toString methods display messages to the user depending
	 * if the solution has been found or not
	 * @return display messages
	 */
	public void isRight(int[][] arr, int Tn) {
		System.out.println("\nyay you found the solution!");
		System.out.println("solution for H(7) where Tn = " + Tn + ":");
		System.out.println("A\tB\tC\tD\tE\tF\tG\n");
		for(int i = 0; i < arr.length; i++) {
			for(int j = 0; j < arr[i].length; j++) {
				System.out.print(arr[i][j] + "\t");
			}
			System.out.println();
		}
		System.out.println("\nmax single covered dots: " + n);
	}
	public void isWrong(int[][]arr) {
		System.out.println("Oops, this combo doesn't work!");
		System.out.println("A\tB\tC\tD\tE\tF\tG\n");
		for(int i = 0; i < arr.length; i++) {
			for(int j = 0; j < arr[i].length; j++) {
				System.out.print(arr[i][j] + "\t");
			}
			System.out.println();
		}
	}
	public int[] getBlobCombo(int i) {
		int[][] bye = {{0},{1},{2},{3},{4},{5},{6},{0,1},{0,2},{0,3},{0,4},
				{0,5},{0,6},{1,2},{1,3},{1,4},{1,5},{1,6},{2,3},{2,4},{2,5},
				{2,6},{3,4},{3,5},{3,6},{4,5},{4,6},{5,6},{0,1,2},{0,1,3},
				{0,1,4},{0,1,5},{0,1,6},{0,2,3},{0,2,4},{0,2,5},{0,2,6},{0,3,4},
				{0,3,5},{0,3,6},{0,4,5},{0,4,6},{0,5,6},{1,2,3},{1,2,4},{1,2,5},
				{1,2,6},{1,3,4},{1,3,5},{1,3,6},{1,4,5},{1,4,6},{1,5,6},{2,3,4},
				{2,3,5},{2,3,6},{2,4,5},{2,4,6},{2,5,6},{3,4,5},{3,4,6},{3,5,6},
				{4,5,6},{0,1,2,3},{0,1,2,4},{0,1,2,5},{0,1,2,6},{0,1,3,4},{0,1,3,5},
				{0,1,3,6},{0,1,4,5},{0,1,4,6},{0,1,5,6},{0,2,3,4},{0,2,3,5},{0,2,3,6},
				{0,2,4,5},{0,2,4,6},{0,2,5,6},{0,3,4,5},{0,3,4,6},{0,3,5,6},{0,4,5,6},
				{1,2,3,4},{1,2,3,5},{1,2,3,6},{1,2,4,5},{1,2,4,6},{1,2,5,6},{1,3,4,5},
				{1,3,4,6},{1,3,5,6},{1,4,5,6},{2,3,4,5},{2,3,4,6},{2,3,5,6},{2,4,5,6},
				{3,4,5,6},{0,1,2,3,4},{0,1,2,3,5},{0,1,2,3,6},{0,1,2,4,5},{0,1,2,4,6},
				{0,1,2,5,6},{0,1,3,4,5},{0,1,3,4,6},{0,1,3,5,6},{0,1,4,5,6},{0,2,3,4,5},
				{0,2,3,4,6},{0,2,3,5,6},{0,2,4,5,6},{0,3,4,5,6},{1,2,3,4,5},{1,2,3,4,6},
				{1,2,3,5,6},{1,2,4,5,6},{1,3,4,5,6},{2,3,4,5,6},{0,1,2,3,4,5},{0,1,2,3,4,6},
				{0,1,2,3,5,6},{0,1,2,4,5,6},{0,1,3,4,5,6},{0,2,3,4,5,6},{1,2,3,4,5,6}};
		int[] blob = bye[i];
		return blob;
	}
	public int[] getToTest(int i) {
		int[][] set = {{0,0,0,0,0,0,0},{1,0,0,0,0,0,0},{0,1,0,0,0,0,0},{1,1,0,0,0,0,0},
				{0,0,1,0,0,0,0},{1,0,1,0,0,0,0},{0,1,1,0,0,0,0},{1,1,1,0,0,0,0},
				{0,0,0,1,0,0,0},{1,0,0,1,0,0,0},{0,1,0,1,0,0,0},{1,1,0,1,0,0,0},
				{0,0,1,1,0,0,0},{1,0,1,1,0,0,0},{0,1,1,1,0,0,0},{1,1,1,1,0,0,0},
				{0,0,0,0,1,0,0},{1,0,0,0,1,0,0},{0,1,0,0,1,0,0},{1,1,0,0,1,0,0},
				{0,0,1,0,1,0,0},{1,0,1,0,1,0,0},{0,1,1,0,1,0,0},{1,1,1,0,1,0,0},
				{0,0,0,1,1,0,0},{1,0,0,1,1,0,0},{0,1,0,1,1,0,0},{1,1,0,1,1,0,0},
				{0,0,1,1,1,0,0},{1,0,1,1,1,0,0},{0,1,1,1,1,0,0},{1,1,1,1,1,0,0},
				{0,0,0,0,0,1,0},{1,0,0,0,0,1,0},{0,1,0,0,0,1,0},{1,1,0,0,0,1,0},
				{0,0,1,0,0,1,0},{1,0,1,0,0,1,0},{0,1,1,0,0,1,0},{1,1,1,0,0,1,0},
				{0,0,0,1,0,1,0},{1,0,0,1,0,1,0},{0,1,0,1,0,1,0},{1,1,0,1,0,1,0},
				{0,0,1,1,0,1,0},{1,0,1,1,0,1,0},{0,1,1,1,0,1,0},{1,1,1,1,0,1,0},
				{0,0,0,0,1,1,0},{1,0,0,0,1,1,0},{0,1,0,0,1,1,0},{1,1,0,0,1,1,0},
				{0,0,1,0,1,1,0},{1,0,1,0,1,1,0},{0,1,1,0,1,1,0},{1,1,1,0,1,1,0},
				{0,0,0,1,1,1,0},{1,0,0,1,1,1,0},{0,1,0,1,1,1,0},{1,1,0,1,1,1,0},
				{0,0,1,1,1,1,0},{1,0,1,1,1,1,0},{0,1,1,1,1,1,0},{1,1,1,1,1,1,0},
				{0,0,0,0,0,0,1},{1,0,0,0,0,0,1},{0,1,0,0,0,0,1},{1,1,0,0,0,0,1},
				{0,0,1,0,0,0,1},{1,0,1,0,0,0,1},{0,1,1,0,0,0,1},{1,1,1,0,0,0,1},
				{0,0,0,1,0,0,1},{1,0,0,1,0,0,1},{0,1,0,1,0,0,1},{1,1,0,1,0,0,1},
				{0,0,1,1,0,0,1},{1,0,1,1,0,0,1},{0,1,1,1,0,0,1},{1,1,1,1,0,0,1},
				{0,0,0,0,1,0,1},{1,0,0,0,1,0,1},{0,1,0,0,1,0,1},{1,1,0,0,1,0,1},
				{0,0,1,0,1,0,1},{1,0,1,0,1,0,1},{0,1,1,0,1,0,1},{1,1,1,0,1,0,1},
				{0,0,0,1,1,0,1},{1,0,0,1,1,0,1},{0,1,0,1,1,0,1},{1,1,0,1,1,0,1},
				{0,0,1,1,1,0,1},{1,0,1,1,1,0,1},{0,1,1,1,1,0,1},{1,1,1,1,1,0,1},
				{0,0,0,0,0,1,1},{1,0,0,0,0,1,1},{0,1,0,0,0,1,1},{1,1,0,0,0,1,1},
				{0,0,1,0,0,1,1},{1,0,1,0,0,1,1},{0,1,1,0,0,1,1},{1,1,1,0,0,1,1},
				{0,0,0,1,0,1,1},{1,0,0,1,0,1,1},{0,1,0,1,0,1,1},{1,1,0,1,0,1,1},
				{0,0,1,1,0,1,1},{1,0,1,1,0,1,1},{0,1,1,1,0,1,1},{1,1,1,1,0,1,1},
				{0,0,0,0,1,1,1},{1,0,0,0,1,1,1},{0,1,0,0,1,1,1},{1,1,0,0,1,1,1},
				{0,0,1,0,1,1,1},{1,0,1,0,1,1,1},{0,1,1,0,1,1,1},{1,1,1,0,1,1,1},
				{0,0,0,1,1,1,1},{1,0,0,1,1,1,1},{0,1,0,1,1,1,1},{1,1,0,1,1,1,1},
				{0,0,1,1,1,1,1},{1,0,1,1,1,1,1},{0,1,1,1,1,1,1},{1,1,1,1,1,1,1}};
		int[] toTest = set[i];
		return toTest;
	}
}


