package seven;
/**
 * tester class for manually tested H(n)
 * 
 * @author lauren ostrea
 * @version 3 March 2021
 */

import java.util.*;
public class TestSeven{
	private final int n = 7; //refers to H(n)
	private int[][] testTable;
	private int[][][] testArray;
	
	/**
	 * constructor method
	 */
	public TestSeven() {
		this.testTable=testTable;
	}
	
	/**
	 * finds the lower bound Tn where k1 = 1 
	 * and kn = (n/2)+k(n/2)+k(n+1/2)
	 * @return Tn (lower)
	 */
	public int findLowerTn(int n) {
		int Tn;
		int tLeft, tRight;
		int N = 2;
		int Kn[] = new int[n];
		Kn[0]=1; //permanently sets H(1) = 1
		
		for(int i = 1; i<Kn.length; i++) { //loop to find Tn
			tLeft = N/2; //root of T(n/2)
			tRight = (N+1)/2; //root of T(n+1/2)
			Tn = N/2 + Kn[tLeft - 1] +Kn[tRight - 1];
			Kn[i] = Tn;
			N++;
		}
			Tn = Kn[n-1]; //finds last value in array
			return Tn; 				
	}
	/**
	 * finds the upper bound Tn where k1 = 1 
	 * and kn = (n/2)+k(n/2)+k(n+1/2)
	 * @return Tn (upper)
	 */
	public int findUpperTn(int n) {
		int lowTn = findLowerTn(n);
		int upTn = lowTn + 1;
		return upTn;
	}
	/**
	 * initializes table of 0 according to n-input.
	 * then fills in values for lower bound Tn. 
	 * the size of table is rows = Tn and col = n
	 */
	public int[][] createLower(int n) {
		int Tn = findLowerTn(n);
		int basement = Tn - 2;
		testTable = new int [Tn][n];
		
		for(int i = 0; i < testTable.length; i++){
			for(int j = 0; j < testTable[i].length; j++){
				if(i<=n) { //fills top half of table with matrix I[n][n]
					if(i==j) testTable[i][i] =1;
					else testTable[i][j]=0;
				}
				if(i > n-1 && i<basement) {  //fills rows 8-13 with test values
					testTable[i]=getSet(i);
				}
				if(i>=basement) { //fills bottom (basement) of table
					testTable[i][j]=1; //bottom two rows filled with 1
				}
			}
		} return testTable;
	}
	/**
	 * initializes table of 0 according to n-input.
	 * then fills in values for upper bound Tn+1. 
	 * the size of table is rows = Tn+1 and col = n
	 */
	public int[][] createUpper(int n, int Tn, int t) {
		int basement = Tn - 2;
		testTable = new int [Tn][n];
		for(int i = 0; i < testTable.length; i++){
			for(int j = 0; j < testTable[i].length; j++){
				if(i<=n) { //fills top half of table with matrix I[n]
					if(i==j) testTable[i][i] =1;
					else testTable[i][j]=0;
				}
				if(i>n-1 && i<=13) { //fills rows 8-13
					testTable[i]=getSet(i);
				}
				if(i>=14 && i<basement) { //fills rows to test
					//for(t = 0; t < 128; t++) {
						testTable[i]=getToTest(t);
					//}
				}
				if(i>=basement) { //fills bottom (basement) of table
					testTable[i][j]=1; //bottom two rows filled with 1
				}
			}
		} return testTable;
	}
	/**
	 * fills the middle of test table
	 * @return 1D array 
	 */
	public int[] getSet(int i){
		int[][] set = {{1,1,0,0,0,0,0},{0,0,1,1,0,0,0},{0,0,0,0,1,1,0},
				{0,0,0,0,1,1,1},{1,1,1,1,0,0,0},{1,1,1,1,0,0,0},{1,0,0,1,0,1,1}};
		int[] toSet = set[i-7];
		return toSet;
	}
	public int[] getToTest(int i) {
		int[][] set = {{0,0,0,0,0,0,0},{1,0,0,0,0,0,0},{0,1,0,0,0,0,0},{1,1,0,0,0,0,0},
				{0,0,1,0,0,0,0},{1,0,1,0,0,0,0},{0,1,1,0,0,0,0},{1,1,1,0,0,0,0},
				{0,0,0,1,0,0,0},{1,0,0,1,0,0,0},{0,1,0,1,0,0,0},{1,1,0,1,0,0,0},
				{0,0,1,1,0,0,0},{1,0,1,1,0,0,0},{0,1,1,1,0,0,0},{1,1,1,1,0,0,0},
				{0,0,0,0,1,0,0},{1,0,0,0,1,0,0},{0,1,0,0,1,0,0},{1,1,0,0,1,0,0},
				{0,0,1,0,1,0,0},{1,0,1,0,1,0,0},{0,1,1,0,1,0,0},{1,1,1,0,1,0,0},
				{0,0,0,1,1,0,0},{1,0,0,1,1,0,0},{0,1,0,1,1,0,0},{1,1,0,1,1,0,0},
				{0,0,1,1,1,0,0},{1,0,1,1,1,0,0},{0,1,1,1,1,0,0},{1,1,1,1,1,0,0},
				{0,0,0,0,0,1,0},{1,0,0,0,0,1,0},{0,1,0,0,0,1,0},{1,1,0,0,0,1,0},
				{0,0,1,0,0,1,0},{1,0,1,0,0,1,0},{0,1,1,0,0,1,0},{1,1,1,0,0,1,0},
				{0,0,0,1,0,1,0},{1,0,0,1,0,1,0},{0,1,0,1,0,1,0},{1,1,0,1,0,1,0},
				{0,0,1,1,0,1,0},{1,0,1,1,0,1,0},{0,1,1,1,0,1,0},{1,1,1,1,0,1,0},
				{0,0,0,0,1,1,0},{1,0,0,0,1,1,0},{0,1,0,0,1,1,0},{1,1,0,0,1,1,0},
				{0,0,1,0,1,1,0},{1,0,1,0,1,1,0},{0,1,1,0,1,1,0},{1,1,1,0,1,1,0},
				{0,0,0,1,1,1,0},{1,0,0,1,1,1,0},{0,1,0,1,1,1,0},{1,1,0,1,1,1,0},
				{0,0,1,1,1,1,0},{1,0,1,1,1,1,0},{0,1,1,1,1,1,0},{1,1,1,1,1,1,0},
				{0,0,0,0,0,0,1},{1,0,0,0,0,0,1},{0,1,0,0,0,0,1},{1,1,0,0,0,0,1},
				{0,0,1,0,0,0,1},{1,0,1,0,0,0,1},{0,1,1,0,0,0,1},{1,1,1,0,0,0,1},
				{0,0,0,1,0,0,1},{1,0,0,1,0,0,1},{0,1,0,1,0,0,1},{1,1,0,1,0,0,1},
				{0,0,1,1,0,0,1},{1,0,1,1,0,0,1},{0,1,1,1,0,0,1},{1,1,1,1,0,0,1},
				{0,0,0,0,1,0,1},{1,0,0,0,1,0,1},{0,1,0,0,1,0,1},{1,1,0,0,1,0,1},
				{0,0,1,0,1,0,1},{1,0,1,0,1,0,1},{0,1,1,0,1,0,1},{1,1,1,0,1,0,1},
				{0,0,0,1,1,0,1},{1,0,0,1,1,0,1},{0,1,0,1,1,0,1},{1,1,0,1,1,0,1},
				{0,0,1,1,1,0,1},{1,0,1,1,1,0,1},{0,1,1,1,1,0,1},{1,1,1,1,1,0,1},
				{0,0,0,0,0,1,1},{1,0,0,0,0,1,1},{0,1,0,0,0,1,1},{1,1,0,0,0,1,1},
				{0,0,1,0,0,1,1},{1,0,1,0,0,1,1},{0,1,1,0,0,1,1},{1,1,1,0,0,1,1},
				{0,0,0,1,0,1,1},{1,0,0,1,0,1,1},{0,1,0,1,0,1,1},{1,1,0,1,0,1,1},
				{0,0,1,1,0,1,1},{1,0,1,1,0,1,1},{0,1,1,1,0,1,1},{1,1,1,1,0,1,1},
				{0,0,0,0,1,1,1},{1,0,0,0,1,1,1},{0,1,0,0,1,1,1},{1,1,0,0,1,1,1},
				{0,0,1,0,1,1,1},{1,0,1,0,1,1,1},{0,1,1,0,1,1,1},{1,1,1,0,1,1,1},
				{0,0,0,1,1,1,1},{1,0,0,1,1,1,1},{0,1,0,1,1,1,1},{1,1,0,1,1,1,1},
				{0,0,1,1,1,1,1},{1,0,1,1,1,1,1},{0,1,1,1,1,1,1},{1,1,1,1,1,1,1}};
		int[] toTest = set[i];
		return toTest;
	}
	public static void getCombo(int[][] sets) {
	    int solutions = 1;
	    for(int i = 0; i < sets.length; solutions *= sets[i].length, i++);
	    for(int i = 0; i < solutions; i++) {
	        int j = 1;
	        for(int[] set : sets) {
	            System.out.print(set[(i/j)%set.length] + " ");
	            j *= set.length;
	        }
	        System.out.println();
	    }
	}
	
	/**
	 * gets the total sum of all columns in the test table
	 * where no blobs (columns) have been deleted yet
	 * @return 2D array 
	 */
	public int[] getSum(int n, int[][] arr) {
		int total;
		int[] sum = new int[arr.length];
		for(int i = 0; i < arr.length; i++) {
			total = 0;
			for(int j = 0; j<arr[i].length;j++) {
				total+= arr[i][j];
			}
			sum[i]=total;
		}
		return sum;
	}
	/**
	 * checks that a column in the test table is <= 7
	 * @return true if check <=7, false if check > 7
	 */
	public boolean checkSum(int[] sum) {
		int ones=0;
		boolean check = false;
		for(int s = 0; s<sum.length; s++) {
			if(sum[s] == 1) ones+=sum[s];
		}
		if(ones <= n) check = true;
		else check = false;
		return check;
	}
	public void printSum(int[] sum, int[][] arr) {
		boolean check = checkSum(sum);
		System.out.println("\nAdding columns together...");
		if(check = true) {
			for(int i = 0; i < arr.length; i++) {
				for(int j = 0; j < arr[i].length; j++) {
					System.out.print(arr[i][j] + "\t");
				}
				System.out.println();
			}
			String total = Arrays.toString(sum);
			System.out.println(total + " --> " + check);
		}
		else {
			System.out.println("Oops, this doesn't work!");
		}
	}
	
	public int[][] removeBlobTest(int n, int[][] test){
		int[] sum, blob;
		int [][] newArray;
		int length, colRemove;
		int row = test.length;
		int col = test[0].length;
		
		for(int b = 0; b < 128; b++) { //parse through blob combinations
			length = getBlob(b).length;
			newArray = new int[row][col - length];
			for(int i = 0; i<row; i++) { //start removing blobs
				for(int j = 0, colCurrent = 0; j<col; j++) {
					for(int a = 0; a < length; a++) {
						blob = getBlob(a);
						
						
					}
					
					
					if(j != colRemove) {
		                newArray[i][colCurrent++] = test[i][j];
		            }
				}
			}
		}
		sum = getSum(n,test); 
		printSum(sum, test);
		
		return newArray;
	}
	
	public int[] getBlob(int i) {
		int[][] bye = {{0},{1},{2},{3},{4},{5},{6},{0,1},{0,2},{0,3},{0,4},
				{0,5},{0,6},{1,2},{1,3},{1,4},{1,5},{1,6},{2,3},{2,4},{2,5},
				{2,6},{3,4},{3,5},{3,6},{4,5},{4,6},{5,6},{0,1,2},{0,1,3},
				{0,1,4},{0,1,5},{0,1,6},{0,2,3},{0,2,4},{0,2,5},{0,2,6},{0,3,4},
				{0,3,5},{0,3,6},{0,4,5},{0,4,6},{0,5,6},{1,2,3},{1,2,4},{1,2,5},
				{1,2,6},{1,3,4},{1,3,5},{1,3,6},{1,4,5},{1,4,6},{1,5,6},{2,3,4},
				{2,3,5},{2,3,6},{2,4,5},{2,4,6},{2,5,6},{3,4,5},{3,4,6},{3,5,6},
				{4,5,6},{0,1,2,3},{0,1,2,4},{0,1,2,5},{0,1,2,6},{0,1,3,4},{0,1,3,5},
				{0,1,3,6},{0,1,4,5},{0,1,4,6},{0,1,5,6},{0,2,3,4},{0,2,3,5},{0,2,3,6},
				{0,2,4,5},{0,2,4,6},{0,2,5,6},{0,3,4,5},{0,3,4,6},{0,3,5,6},{0,4,5,6},
				{1,2,3,4},{1,2,3,5},{1,2,3,6},{1,2,4,5},{1,2,4,6},{1,2,5,6},{1,3,4,5},
				{1,3,4,6},{1,3,5,6},{1,4,5,6},{2,3,4,5},{2,3,4,6},{2,3,5,6},{2,4,5,6},
				{3,4,5,6},{0,1,2,3,4},{0,1,2,3,5},{0,1,2,3,6},{0,1,2,4,5},{0,1,2,4,6},
				{0,1,2,5,6},{0,1,3,4,5},{0,1,3,4,6},{0,1,3,5,6},{0,1,4,5,6},{0,2,3,4,5},
				{0,2,3,4,6},{0,2,3,5,6},{0,2,4,5,6},{0,3,4,5,6},{1,2,3,4,5},{1,2,3,4,6},
				{1,2,3,5,6},{1,2,4,5,6},{1,3,4,5,6},{2,3,4,5,6},{0,1,2,3,4,5},{0,1,2,3,4,6},
				{0,1,2,3,5,6},{0,1,2,4,5,6},{0,1,3,4,5,6},{0,2,3,4,5,6},{1,2,3,4,5,6}};
		int[] blob = bye[i];
		return blob;
	}
	
	public void createTest(int n) {
		int Tn = findUpperTn(n);
		int k=0;
		int[] sum;
		int[] bye = new int[128];
		int[][] low = createLower(n);
		int[][] up = createUpper(n,Tn,k);
		
		boolean checkFirst;
		boolean test = true;
		boolean checkAll = true;
		
		System.out.println("H(7): testing tables...");
			sum = getSum(n,up); //gets sum of 1's with no blobs removed
			printSum(sum, up);
			checkFirst = checkSum(sum); //checks if sum <= 7
			
			if(checkFirst = true) { //if sum <= 7, run blob test
				do { //test table until all blobs have been checked
					sum = getSum(n,up); //gets sum of 1's with no blobs removed
					checkFirst = checkSum(sum); //checks if sum <= 7
					for(int i = 0; i<bye.length; i++) {
						//starts blob test and removes blobs
						int[][] noBlob = removeBlob(n,up);
						sum = getSum(n,noBlob);
						checkAll = checkSum(sum);
						printSum(sum, noBlob);
						
						if(checkAll = false) {
							isWrong(up);
							test = false;
							break;
						}
						if(i==bye.length-1) { //if done with blob test, end loop
							isRight(up, Tn);
							test = true;
							break; 					
						}
						//k+=1;
					}
				} while(checkAll!=false); //end when single covered dots > 7
			}
			else if(checkFirst = false) { //if sum > 7, end test
				isWrong(up);
			}
	}
	
	/**
	 * toString methods display messages to the user depending
	 * if the solution has been found or not
	 * @return display messages
	 */
	public void isRight(int[][] arr, int Tn) {
		System.out.println("\nyay you found the solution!");
		System.out.println("solution for H(7) where Tn = " + Tn + ":");
		System.out.println("A\tB\tC\tD\tE\tF\tG\n");
		for(int i = 0; i < arr.length; i++) {
			for(int j = 0; j < arr[i].length; j++) {
				System.out.print(arr[i][j] + "\t");
			}
			System.out.println();
		}
		System.out.println("\nmax single covered dots: " + n);
	}
	public void isWrong(int[][]arr) {
		System.out.println("Oops, this doesn't work!");
		System.out.println("A\tB\tC\tD\tE\tF\tG\n");
		for(int i = 0; i < arr.length; i++) {
			for(int j = 0; j < arr[i].length; j++) {
				System.out.print(arr[i][j] + "\t");
			}
			System.out.println();
		}
	}
}


