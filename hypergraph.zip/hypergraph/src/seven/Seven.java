package seven;
/**
 * tests hypergraph models with xlsx file or
 * manually, then finds solution for H(7)
 * 
 * @author lauren ostrea
 * @version 3 March 2021
 */

import java.util.*;
public class Seven {
	public static void main(String[] args) 
	{
		TestSeven test = new TestSeven();//create test object
	    System.out.println("Welcome to the hypergraph test");
		int n=7; 
		test.createTest(n);
		
	} //end main
} //end class

