module hypergraph {
}