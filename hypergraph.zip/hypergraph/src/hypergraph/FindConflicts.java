package hypergraph;

public class FindConflicts {
	
    public boolean findBadRow(int[][]find, int a) //finds row conflicts
    { 
        boolean bad = false;
        int count = 0;
      
        for(int i = 0; i < 8; i++){
            if(find[i][a] == 1){
                count++;
            }
        }
        if(count > 1){
            bad = true;
        }
        return bad;
    }    
    public boolean findBadCol(int[][]find, int b)//finds column conflicts
    { 
        boolean bad = false;
        int count = 0;
        
        for(int i = 0; i < 8; i++){
            if(find[b][i] == 1){
                count++;
            }
        }
        if(count > 1){
          bad = true;
        }
        return bad;
    }  
    public boolean findBadDia(int[][]find, int a, int b) //finds diagonal conflicts
    {
        boolean diagonal = false;
      
        for(int i = 1; i < 8; i++){
            if(diagonal){
                break;
            }
            if((a+i < 8) && (b+i < 8)){
                if(find[a+i][b+i] == 1){
                    diagonal = true;
                }
            }
            if((a-i >= 0) && (b-i >= 0)){
                if(find[a-i][b-i] == 1){
                    diagonal = true;
                }
            }
            if((a+i < 8) && (b-i >= 0)){
                if(find[a+i][b-i] == 1){
                    diagonal = true;
                }
            }  
            if((a-i >= 0) && (b+i < 8)){
                if(find[a-i][b+i] == 1){
                    diagonal = true;
                }
            }  
        }
        return diagonal;
    } 
    public int heuristic(int[][] find) //counts number of bad queens
    {
    	int count = 0;
    	boolean badRow, badCol, badDia;
      
        for(int i = 0; i < 8; i++){
            for(int j= 0; j < 8; j++){
                if(find[i][j] == 1){
                    badRow = findBadRow(find, j);
                    badCol = findBadCol(find, i);
                    badDia = findBadDia(find, i, j);
                  
                    if(badRow || badCol || badDia){
                        count++;
                    }
                }
            }
        }
        return count;
    }
}
