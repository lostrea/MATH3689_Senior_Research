package hypergraph;
/**
 * generates and tests hypergraph models and
 * finds the most practical solution for each
 * H(n) where n is a positive integer
 * 
 * @author lauren ostrea
 * @version 3 March 2021
 */

import java.util.*;
public class Hypergraph {
	public static void main(String[] args) 
	 {
		 Scanner in = new Scanner(System.in); //create new Scanner
	     
	     System.out.println("Welcome to the hypergraph test");
	     System.out.print("Please enter desired number to test: ");
	     int n = in.nextInt(); //user enters test value i.e. H(n)
	     System.out.println(); //prints new line
	     
	     HypergraphTest test = new HypergraphTest(); //create hypergraph object
	     test.createTest(n); 
	     
	 }
}

