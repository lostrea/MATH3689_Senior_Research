package hypergraph;

import java.util.*;
public class HypergraphTest {
	private int n = 0; //refers to H(n)
	private int restart = 0;
	private boolean newTable = true;
	private int[][] testTable;
	
	/**
	 * constructor method
	 */
	public HypergraphTest() {
		this.testTable=testTable;
	}
	
	/**
	 * finds Tn where k1 = 1 and kn = (n/2)+k(n/2)+k(n+1/2)
	 * @return value of Tn
	 */
	public int findTn(int n) {
		int Tn, tLeft, tRight;
		int N = 2;
		int Kn[] = new int[n];
		Kn[0]=1; //permanently sets H(1) = 1
		
		for(int i = 1; i<Kn.length; i++) { //loop to find Tn
			tLeft = N/2; //root of T(n/2)
			tRight = (N+1)/2; //root of T(n+1/2)
			Tn = N/2 + Kn[tLeft - 1] +Kn[tRight - 1];
			Kn[i] = Tn;
			N++;
		}
			Tn = Kn[n-1]; //finds last value in array
			return Tn; 				
	}
	/**
	 * initializes table of 0 according to n-input.
	 * then fills in values accordingly
	 * the size of table is rows = Tn and col = n
	 */
	public void createTable(int n) {
		int Tn = findTn(n);
		int basement = Tn-n;
		testTable = new int [Tn][n];
		
		for(int i = 0; i < testTable.length; i++){
			for(int j = 0; j < testTable[i].length; j++){
				if(i<=n) { //fills top half of table
					//initializes identity matrix NxN
					if(i==j) testTable[i][i] =1;
					else testTable[i][j]=0;
				}
				//fills bottom half of table
				if(i==Tn-1 && basement<=2) { //if n=2 or n=3
					testTable[i][j]=1; //bottom most row filled with 1
				}
				if(i>=Tn-2 && basement>2) { //if n>3
					testTable[i][j]=1; //bottom two rows filled with 1
				}
			}
		}
		for(int i = 0; i < testTable.length; i++) {
			for(int j = 0; j < testTable[i].length; j++) {
				System.out.print(testTable[i][j] + "\t");
			}
			System.out.println();
		}
	}
	
	public void moveBlob() {
		
	}
	
	
	public void createTest(int n) {
		System.out.println("testing tables...\n");
		System.out.println("solution for H(" + n + "):");
		switch(n) {		
		case 2: 
			System.out.println("A\tB\n");
			createTable(n);
			toString(n);
			break;
		case 3:
			System.out.println("A\tB\tC\n");
			createTable(n);
			break;
		case 4:
			System.out.println("A\tB\tC\tD\n");
			createTable(n);
			break;
		case 5:
			System.out.println("A\tB\tC\tD\tE\n");
			createTable(n);
			break;
		case 6:
			System.out.println("A\tB\tC\tD\tE\tF\n");
			createTable(n);
			break;
		case 7:
			System.out.println("A\tB\tC\tD\tE\tF\tG\n");
			createTable(n);
			break;
		}
	}
	public static void removeBlob(int n) {
		
	}
	
	public static void removeBlobs(int n) {
		int blob = (int) Math.pow(2,n);
		for(int i = 0; i < blob; i++){
			switch(i) {
			case 0: 
				System.out.println("\nblobs removed: none\n");
			case 1:
				
				
			}
		}
	}
	public void toString(int n){
		System.out.println("\ntotal single covered dots: "+n);
		System.out.println("H(" + n + ") has been found!");
	}
	
}


