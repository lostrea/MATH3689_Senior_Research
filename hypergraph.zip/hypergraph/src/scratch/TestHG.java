package scratch;
/**
 * tester class for manually tested H(n)
 * 
 * @author lauren ostrea
 * @version 3 March 2021
 */

import java.util.*;
public class TestHG {
	private int n = 0; //refers to H(n)
	private int restart = 0;
	private boolean newTable = true;
	private int[] num = {0,1};
	private int[][] testTable, tableList;
	private int[][][] testArray, arrayList;
	
	/**
	 * constructor method
	 */
	public TestHG() {
		this.testTable=testTable;
	}
	
	/**
	 * finds the lower bound Tn where k1 = 1 
	 * and kn = (n/2)+k(n/2)+k(n+1/2)
	 * @return Tn (lower)
	 */
	public int findLowerTn(int n) {
		int Tn;
		int tLeft, tRight;
		int N = 2;
		int Kn[] = new int[n];
		Kn[0]=1; //permanently sets H(1) = 1
		
		for(int i = 1; i<Kn.length; i++) { //loop to find Tn
			tLeft = N/2; //root of T(n/2)
			tRight = (N+1)/2; //root of T(n+1/2)
			Tn = N/2 + Kn[tLeft - 1] +Kn[tRight - 1];
			Kn[i] = Tn;
			N++;
		}
			Tn = Kn[n-1]; //finds last value in array
			return Tn; 				
	}
	/**
	 * finds the upper bound Tn where k1 = 1 
	 * and kn = (n/2)+k(n/2)+k(n+1/2)
	 * @return Tn (upper)
	 */
	public int findUpperTn(int n) {
		int lowTn = findLowerTn(n);
		int upTn = lowTn + 1;
		return upTn;
	}
	/**
	 * initializes table of 0 according to n-input.
	 * then fills in values for lower bound Tn. 
	 * the size of table is rows = Tn and col = n
	 */
	public void createLower(int n) {
		int Tn = findLowerTn(n);
		int basement = Tn - n;
		testTable = new int [Tn][n];
		for(int i = 0; i < testTable.length; i++){
			for(int j = 0; j < testTable[i].length; j++){
				if(i<=n) { //fills top half of table with matrix I[n]
					if(i==j) testTable[i][i] =1;
					else testTable[i][j]=0;
				}
				//fills middle part of table (to be tested)
//				if(i>n && i<Tn-2) {
//					
//				}
				//fills bottom half of table
				if(i==Tn-1 && basement<=2) { //if n=2 or n=3
					testTable[i][j]=1; //bottom most row filled with 1
				}
				if(i>=Tn-2 && basement>2) { //if n>3
					testTable[i][j]=1; //bottom two rows filled with 1
				}
			}
		}
		for(int i = 0; i < testTable.length; i++) {
			for(int j = 0; j < testTable[i].length; j++) {
				System.out.print(testTable[i][j] + "\t");
			}
			System.out.println();
		}
	}
	/**
	 * initializes table of 0 according to n-input.
	 * then fills in values for upper bound Tn+1. 
	 * the size of table is rows = Tn+1 and col = n
	 */
	public void createUpper(int n) {
		int Tn = findUpperTn(n);
		int basement = Tn - n;
		testTable = new int [Tn][n];
		for(int i = 0; i < testTable.length; i++){
			for(int j = 0; j < testTable[i].length; j++){
				if(i<=n) { //fills top half of table with matrix I[n]
					if(i==j) testTable[i][i] =1;
					else testTable[i][j]=0;
				}
				//fills middle part of table (to be tested)
//				if(i>n && i<Tn-2) {
//					
//				}
				//fills bottom half of table
				if(i==Tn-1 && basement<=2) { //if n=2 or n=3
					testTable[i][j]=1; //bottom most row filled with 1
				}
				if(i>=Tn-2 && basement>2) { //if n>3
					testTable[i][j]=1; //bottom two rows filled with 1
				}
			}
		}
		for(int i = 0; i < testTable.length; i++) {
			for(int j = 0; j < testTable[i].length; j++) {
				System.out.print(testTable[i][j] + "\t");
			}
			System.out.println();
		}
	}
	public int getFactorial(int n) {
		int fact=1;
		for(int i = 1; i < n+1; i++) {
			fact = fact * i;
		}
		return fact;
	}
	public int getArrayPos(int n) {
		int fact = getFactorial(n);
		int pow = (int) Math.pow(2,n);
		int pos=((fact*pow)/n)-1;
		return pos;
	}
	/**
	 * method to find all of the possible permutations
	 * of H(n) that need to be tested
	 * @return 3D array
	 */
	public void getPerm(int n, int Tn){
		int bottom = Tn - n;
		int row = Tn - bottom - 1;
		int pos = getArrayPos(n);
		tableList = new int[row][n];
		testArray = new int [pos][row][n];
		int len = tableList.length;
		for(int i=0; i<pos; i++) {
			for(int j=0; j<row; j++) {
				for(int k = 0; k<n; k++) {
					//testArray[testArray.length-1]=findPerm(n);
				}
				//testArray[i]=findPerm(n);
			}
		}
		for(int i=0; i<pos; i++) {
			for(int j=0; j<row; j++) {
				for(int k = 0; k<n; k++) {
					System.out.print(" " + testArray[i][j][k]);
				}
				System.out.println("");
			}
			System.out.println("");
		}
		
	}
	public void findPerm(int n) {
		int Tn = findUpperTn(n);
		int pos = getArrayPos(n);
		int row = Tn-n-1;
		tableList = new int[row][n];
		arrayList = new int[pos][row][n]; 
		int len = tableList.length;
		
		for(int i = 0; i<tableList.length; i++) {
			for(int j = 0; j<tableList[i].length; j++) {
				if(i==row-1) tableList[i][j]=1;
				else tableList[i][j]=0;
			}
		}
		for(int i = 0; i < tableList.length; i++) {
			for(int j = 0; j < tableList[i].length; j++) {
				System.out.print(tableList[i][j] + "\t");
			}
			System.out.println();
		}
		//return tableList;
	}
	
	/**
	 * method to check that if removeBlob() is false,
	 * then close reference array
	 * @param 2D tester array, n
	 * @return true or false
	 */
	public boolean isClosed(int[][] a, int n) {
		boolean blob = removeBlob(n);
		boolean check = false;
		if(blob==false) {
			//close array reference
			check = false;
		}
		else if(blob==true) {
			//keep true array 
			check = true;
		}
		return check;
	}
	/**
	 * method to remove each blob combo from table
	 * @return
	 */
	public boolean removeBlob(int n) {
		boolean check = false;
		int added = 0;
		int cycle = (int) Math.pow(2,n);
		while(added <= n) {
			for(int i = 0; i > cycle-1; i++) {
				
			}
		}
		
		
		
		return check;
	}
	
	public static void removeBlobs(int n) {
		int blob = (int) Math.pow(2,n);
		for(int i = 0; i < blob; i++){
			switch(i) {
			case 0: 
				System.out.println("\nblobs removed: none\n");
			case 1:
				
				
			}
		}
	}
	public void createTest(int n) {
		//int Tn = findUpperTn(n);
		int Tn = findLowerTn(n);
		System.out.println("testing tables...\n");
		System.out.println("solution for H(" + n + "):");
		switch(n) {		
		case 2: 
			System.out.println("A\tB\n");
			createLower(n);
			toString(n);
			break;
		case 3:
			System.out.println("A\tB\tC\n");
			//createLower(n);
			findPerm(n);
			//getPerm(n,Tn);
			break;
		case 4:
			System.out.println("A\tB\tC\tD\n");
			findPerm(n);
			getPerm(n,Tn);
			break;
		case 5:
			System.out.println("A\tB\tC\tD\tE\n");
			getPerm(n,Tn);
			break;
		case 6:
			System.out.println("A\tB\tC\tD\tE\tF\n");
			getPerm(n,Tn);
			break;
		case 7:
			System.out.println("A\tB\tC\tD\tE\tF\tG\n");
			getPerm(n,Tn);
			break;
		}
	}
	
	public void toString(int n){
		System.out.println("max single covered dots: "+n);
		System.out.println("H(" + n + ") is within the bounds:  " 
				+ findLowerTn(n) + " <= H(" + n + ") <= " + findUpperTn(n));
	}
}


