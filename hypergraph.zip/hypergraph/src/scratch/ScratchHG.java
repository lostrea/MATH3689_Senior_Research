package scratch;
/**
 * tests hypergraph models with xlsx file or
 * manually, then finds solution for each
 * H(n) where n is a positive integer
 * 
 * @author lauren ostrea
 * @version 3 March 2021
 */

import java.util.*;
public class ScratchHG {
	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in); //create new Scanner
		TestHG test = new TestHG();//create test object
		 
//	    System.out.println("Welcome to the hypergraph test");
//	    System.out.println("\tMenu:\n\t\t\n" 
//	    		+ "1. import xlsx file to find H(n)\n\t\t"
//	    		+ "2. manually enter H(n)"); //display menu
//	     
//	    //prompts user to enter menu choice
//	    System.out.print("\nplease enter choice:");
//	    int choice = in.nextInt();
//	    System.out.println();
//	    
//	    //menu choice 1: use xlsx file
//	    if(choice == 1) {
//	     
//	    	 
//	    }
//	    else if(choice == 2) {// menu choice 2: manual find
	    	System.out.print("Please enter desired number to test: ");
		    int n = in.nextInt(); //user enters test value i.e. H(n)
		    System.out.println(); 
		    test.createTest(n); 
//	    }
//	    else {
//	    	System.out.println("invalid menu choice - please try again");
//	    }
	} //end main
} //end class

